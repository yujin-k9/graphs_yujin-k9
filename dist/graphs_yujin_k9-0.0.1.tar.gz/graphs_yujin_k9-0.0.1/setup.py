from setuptools import setup, find_packages

setup(
    name="graphs_yujin_k9",
    version="0.0.1",
    description="A Python package for Dijkstra's algorithm and other graph-related algorithms.",
    author="Kaylee Kim",
    author_email="ykim28627@gmail.com",
    packages=["graphs_yujin_k9"],
    install_requires=[],
)